const toggleButton = document.getElementById('btn');
const body = document.body;
const light = document.querySelector('.light');

toggleButton.addEventListener('click', () => {
    body.classList.toggle('dark-mode');
    
});
const menuIcon = document.querySelector('.menu-icon');
const menu = document.querySelector('.menu');

menuIcon.addEventListener('click', () => {
    menu.style.display = menu.style.display === 'none' ? 'block' : 'none';
});